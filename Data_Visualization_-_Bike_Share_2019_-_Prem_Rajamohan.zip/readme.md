# Bay Wheels Bike Share Data - 2019
## by Prem Rajamohan

## Dataset

Bay Wheels is a public bike sharing system in the San Francisco Bay Area, CA. Having lived in SFO for a few years, I have seen hundreds of people biking every day to/from work. This was one of the motivations for me to choose this dataset out of the available options. The data used for the exploratory and explanatory analysis here consists of bike rides for the whole year of 2019. There is data for 2018 and 2019 but I am subsetting the data to just 2019 since the whole dataset turns out to be 4 MM and 2019 is 60% of that. There are fields like bike ID, station information, duration information etc. This can also be downloaded from here - https://www.lyft.com/bikes/bay-wheels/system-data. The data set was mostly clean but I did a couple of data wrangling steps, namely, converted time field from string to date time and used that to create derived fields to indicate hour, day, and month of the trips.

## Summary of Findings

Most of the trips were short trips and mainly fell within 4-10 minutes. 99% of the trips were under an hour and 90% of the trips were within 20 minutes. Bike usage behaviour varied significantly by hour (there was a spike in usage during rush hours in the morning and evening), by day (weekday usage was more but weekends saw longer trips in general), and by month (Summer months saw an increased usage). It was also seen that subscribers make up majority of the bike users and they have shorter trips when compared to customers (non-subscribers). Between subscribers and customers, there is a clear difference in usage behaviour and customers tend to take much longer rides on weekends compared to subscribers.

## Key Insights for Presentation

The main insights for me are around trip duration, user types, and the interaction between the two. As one would expect, most trips are short trips (4-10 minutes) since professional people (probably most of the subscriber group) are using bike rides to commute to/from work. Majority of the bike usage is from subscribers who use it more frequently for a fixed purpose and hence have a smaller spread in average trip duration. There is also a good difference in bike usage depending on the day of the week and weekends see longer trips on average compared to weekdays. Also, customers tend to take much longer trips on weekends when compared to their weekday trips but subscribers tend to take similar trips irrespective of the day. 